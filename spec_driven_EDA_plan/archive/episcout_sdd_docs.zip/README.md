# episcout SDD documentation pack

This pack contains the initial specification-driven development documents for evolving `episcout` into a specification-first exploratory data analysis workflow for biomedical and epidemiological datasets.

## Files

```text
docs/
├─ sdd/
│  ├─ 0001-spec-first-eda.md
│  ├─ mvp-scope.md
│  └─ data-dictionary-spec.md
├─ adr/
│  ├─ README.md
│  ├─ 0001-build-on-episcout.md
│  ├─ 0002-specification-first-workflow.md
│  ├─ 0003-r-not-pure-base-r.md
│  └─ 0004-synthetic-data-before-access.md
├─ codex/
│  ├─ initial-instructions.md
│  ├─ pr-plan.md
│  └─ review-checklist.md
├─ roadmap.md
└─ repository-audit.md
```

## Intended use

1. Copy this `docs/` folder into the root of the `episcout` repository.
2. Commit the documentation first, before code changes.
3. Ask Codex to read `AGENTS.MD`, then `docs/sdd/0001-spec-first-eda.md`, then `docs/codex/initial-instructions.md`.
4. Implement in small pull requests using `docs/codex/pr-plan.md`.

## Development principle

Do not rewrite `episcout` from scratch. The package already has useful epidemiology helper functions. The intended direction is to add a higher-level specification-first workflow layer around the existing functionality.
