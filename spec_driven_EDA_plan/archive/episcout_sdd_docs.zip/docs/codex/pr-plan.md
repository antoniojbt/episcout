# PR plan

## PR 1: Documentation baseline

Purpose:

- add SDD, ADRs, roadmap and Codex instructions.

Files:

```text
docs/sdd/0001-spec-first-eda.md
docs/sdd/mvp-scope.md
docs/sdd/data-dictionary-spec.md
docs/roadmap.md
docs/repository-audit.md
docs/adr/*
docs/codex/*
```

No R code changes.

## PR 2: Baseline audit and checks

Purpose:

- run existing checks;
- record test/coverage baseline;
- identify fragile functions.

Possible files:

```text
docs/baseline-checks.md
```

No functional changes unless required to make checks pass.

## PR 3: Harden existing core stats functions

Purpose:

- improve edge-case handling in existing functions.

Targets:

```text
R/epi_stats_numeric.R
R/epi_stats_na_perc.R
R/epi_stats_summary.R
R/epi_stats_chars.R
R/epi_stats_factors.R
```

Expected tests:

```text
tests/testthat/test-epi_stats_numeric.R
tests/testthat/test-missing-functions.R
tests/testthat/test-epi_stats_chars.R
tests/testthat/test-epi_stats_factors.R
```

## PR 4: Add EDA specification parser

Purpose:

- implement `eda_spec()`;
- implement `validate_eda_spec()`.

New file:

```text
R/eda_spec.R
```

Tests:

```text
tests/testthat/test-eda_spec.R
```

## PR 5: Add synthetic-data generator

Purpose:

- implement `generate_synthetic_data()`.

New file:

```text
R/eda_synthetic.R
```

Tests:

```text
tests/testthat/test-eda_synthetic.R
```

## PR 6: Add schema and missingness profiles

Purpose:

- implement `check_schema()`;
- implement `profile_missing()`.

New files:

```text
R/eda_schema.R
R/eda_missing.R
```

Tests:

```text
tests/testthat/test-eda_schema.R
tests/testthat/test-eda_missing.R
```

## PR 7: Add summary and plot dispatch

Purpose:

- implement `profile_summaries()`;
- implement `profile_plots()`.

New files:

```text
R/eda_summaries.R
R/eda_plots.R
```

Tests:

```text
tests/testthat/test-eda_summaries.R
tests/testthat/test-eda_plots.R
```

## PR 8: Add run_eda orchestration

Purpose:

- implement `run_eda()` as the main workflow function.

New file:

```text
R/run_eda.R
```

Tests:

```text
tests/testthat/test-run_eda.R
```

## PR 9: Add report template

Purpose:

- add Quarto report rendering.

New files:

```text
R/eda_report.R
inst/report-template/eda.qmd
```

Tests:

```text
tests/testthat/test-eda_report.R
```

## PR 10: Add project template

Purpose:

- add reusable project scaffold.

New files:

```text
inst/project-template/
```

Optional helper:

```r
use_episcout_project()
```

## PR 11: Large-data design note

Purpose:

- document and prototype large-data backend strategy.

Do not implement Arrow/DuckDB fully until the MVP API is stable.
