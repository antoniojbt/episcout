# Codex initial instructions

## Context

This repository is `episcout`, an R package for cleaning, exploring and visualising epidemiological datasets.

The development objective is to add a specification-first exploratory data analysis workflow while preserving existing functionality.

## Required reading

Before making changes, read:

1. `AGENTS.MD`
2. `docs/sdd/0001-spec-first-eda.md`
3. `docs/sdd/mvp-scope.md`
4. `docs/sdd/data-dictionary-spec.md`
5. `docs/roadmap.md`
6. `docs/codex/pr-plan.md`
7. `docs/codex/review-checklist.md`

## Development rules

- Use small PRs.
- Do not refactor unrelated code.
- Do not remove existing exported `epi_*` functions in the MVP.
- Add roxygen2 documentation for every exported function.
- Add tests for every new function.
- Keep outputs deterministic where possible.
- Prefer explicit validation and clear error messages.
- Do not add heavy dependencies to `Imports` without justification.
- Use `Suggests` for optional tools where possible.
- Preserve existing package behaviour unless the PR explicitly fixes a documented bug.

## First PR instruction

Add only documentation:

- `docs/sdd/0001-spec-first-eda.md`
- `docs/sdd/mvp-scope.md`
- `docs/sdd/data-dictionary-spec.md`
- `docs/roadmap.md`
- `docs/repository-audit.md`
- `docs/adr/*`
- `docs/codex/*`

Do not change R code in the first PR.

## Later PR behaviour

Each code PR should include:

- short summary;
- motivation;
- files changed;
- tests added;
- backward-compatibility notes;
- manual checks run.

## Commands to run locally

```bash
Rscript -e "devtools::document()"
Rscript -e "devtools::test(reporter = 'summary')"
Rscript -e "devtools::check(manual = FALSE)"
```

Where available:

```bash
Rscript -e "styler::style_pkg()"
Rscript -e "lintr::lint_package()"
Rscript -e "covr::report()"
```

## Preferred implementation style

- Use 2-space indentation.
- Use `snake_case`.
- Use small functions.
- Return plain objects.
- Avoid hidden state.
- Avoid `<<-` and `assign()`.
- Avoid broad refactors unless separately requested.
- Avoid changing generated `man/` files without running roxygen2 documentation.
