# MVP scope

## Goal

Deliver the smallest useful specification-first EDA workflow on top of `episcout`.

The MVP should prove that a project can be prepared before data access and then rerun unchanged once real data arrive.

## Included

### Specification

- read CSV data dictionary;
- validate required columns;
- validate allowed variable types;
- support missing-value code declarations;
- support valid ranges and allowed levels;
- return a standard tibble-like object.

### Synthetic data

- generate synthetic data from the specification;
- support numeric, integer, categorical, binary, date, datetime and text variables;
- set deterministic seed;
- clearly label synthetic outputs;
- provide enough realism to test code, plots and reports.

### Schema checks

- compare expected variables with observed variables;
- flag missing variables;
- flag unexpected variables;
- optionally flag type mismatches;
- return machine-readable output.

### Missingness

- missing count per variable;
- missing percentage per variable;
- non-missing count;
- distinct non-missing value count;
- optional row-level missingness.

### Summaries

- numeric summaries: n, missing, mean, SD, median, quartiles, min, max, IQR, outlier counts;
- categorical summaries: n, missing, number of levels, top levels;
- character summaries: missing, empty strings, whitespace strings, unique values;
- date summaries: min, max, missing, observed date range.

### Plots

- numeric: histogram;
- categorical/binary: bar plot;
- date: date-frequency plot;
- text: no default plot in MVP unless low-cardinality;
- one plot per variable;
- save plots as files and/or return plot objects.

### Reporting

- HTML Quarto report first;
- sections for schema, missingness, summaries and plots;
- clear synthetic vs real data labelling;
- no expensive recomputation inside the report.

### Project template

Provide a basic project scaffold:

```text
metadata/data_dictionary.csv
config/eda.yml
_targets.R
reports/eda.qmd
R/project-derivations.R
outputs/
```

## Excluded from MVP

- CRAN release;
- full Arrow backend;
- full DuckDB backend;
- full data.table backend;
- disclosure-control synthetic data;
- causal modelling;
- prediction modelling;
- final manuscript tables;
- complex longitudinal simulation;
- imputation;
- interactive Shiny dashboard;
- PDF/Word report output.

## Risk controls

- keep public API small;
- add tests with every new function;
- do not refactor unrelated existing functions;
- preserve existing `epi_*` functions initially;
- avoid dependency bloat;
- place heavy packages in `Suggests` where possible.

## First implementation order

1. `eda_spec()`
2. `validate_eda_spec()`
3. `generate_synthetic_data()`
4. `check_schema()`
5. `profile_missing()`
6. `profile_summaries()`
7. `profile_plots()`
8. `run_eda()`
9. `render_eda_report()`
10. project template
