# Independent-Truth Review

## Scope and conclusion

- Review date:
- Reviewer:
- Paths and outputs reviewed:
- Overall conclusion:
- Important limitations:

## Methods

Describe inspection commands, evidence-class definitions, inaccessible material, and any constraints on handling confidential data.

## Findings

List findings in priority order. For each finding, cite catalogue IDs, implementation and test paths, the observed validation class, why the gap matters, and the smallest useful improvement.

## Existing strengths

Describe independently anchored checks already present without overstating what they validate.

## Coverage summary

Summarize which important outputs have external-independent, hand-derived, cross-implementation, internal-consistency, smoke-only, or no validation. Derive counts from the catalogue rather than estimating them.

## Recommended next steps

Separate immediate high-value additions from broader improvements. Stop before implementation pending user approval.
