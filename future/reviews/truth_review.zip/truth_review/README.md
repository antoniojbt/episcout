# Independent-Truth Review

Use this workflow only when a user explicitly asks whether analytical tests validate outputs against external, independent truth rather than only internal logic or self-consistency.

Read `WORKFLOW.md`, keep the initial implementation review read-only, and write the report and catalogue under `outputs/robots_output_truth_review/final/`. Stop at the approval gate before changing analytical code or tests.
