# Independent-Truth Validation Repair Plan

Use this only after the review findings are approved and implementation is requested.

## Intended outcome

State which important outputs will gain independently anchored validation and how success will be observed.

## Approved findings

List the truth-review catalogue IDs in scope. Do not add unrelated test refactors.

## Changes

For each catalogue ID, specify the independent source or hand-derived fixture, affected paths, expected behavior, failure behavior, and source-to-output reconciliation.

## Validation

List targeted and broad commands, expected observable outcomes, confidentiality safeguards, and how to detect fixtures accidentally regenerated from production logic.

## Limitations

State remaining outputs without independent validation and any external truth sources that were unavailable.
